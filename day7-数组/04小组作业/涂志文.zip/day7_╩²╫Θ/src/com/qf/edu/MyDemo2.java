package com.qf.edu;

public class MyDemo2 {

	public static void main(String[] args) {
		//����������һ��Ԫ��
		int oldArr[]= {5,6,7,8,9,10};
		int newArr[]=new int[10];
		for (int i = 0; i < oldArr.length; i++) {
			newArr[i]=oldArr[i];
		}
		newArr[oldArr.length]=10;
		for (int i = 0; i < newArr.length; i++) {
			System.out.print(newArr[i]+" ");
		}
	}

}
