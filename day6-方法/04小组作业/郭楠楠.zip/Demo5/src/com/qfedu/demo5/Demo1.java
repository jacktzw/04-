package com.qfedu.demo5;

import java.util.Random;
import java.util.Scanner;

public class Demo1 {
	public static void main(String[] args){
		System.out.print("������һ������n��");
		Scanner sc = new Scanner(System.in);
		int m = sc.nextInt();
		System.out.println(show(m));
		sc.close();
	}
	public static int  show(int m){
		int[] arr = new int[m];
		Random random = new Random();
		for(int i = 0;i < m;i++){
			int n = random.nextInt(100);
			System.out.print(n+" ");
			arr[i] = n;
	}
		System.out.println(" ");
		for(int i = 1;i < arr.length;i++){
			for(int j = 0;j < arr.length-i;j++){
				if(arr[j] > arr[j+1]){
					int temp;
					temp = arr[j+1];
					arr[j+1] = arr[j];
					arr[j] = temp;
				}
			}
		}
		return arr[1];
	}

}
