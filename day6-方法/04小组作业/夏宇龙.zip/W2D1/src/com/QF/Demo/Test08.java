package com.QF.Demo;

import java.util.Random;
import java.util.Scanner;

public class Test08 {
	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		System.out.print("Please input your number:");
		int n=input.nextInt();
		input.close();
		System.out.println(min(n));

	}

	private static String min(int n) {
		int min=100,sec=100,count=0;
		for(int i=0;i<n;i++) {
			Random rand=new Random();
			int number=rand.nextInt(100);
			System.out.print(number+"\t");
			count++;
			if(count%10==0) {
				System.out.println();
			}
			if(number<min) {
				sec=min;
				min=number;
			}
			else if(number<sec||min==sec) {
				sec=number;
			}
		}
		System.out.println();
		return "��Сֵ��"+min+",�ڶ�С��"+sec;
	}	
}
