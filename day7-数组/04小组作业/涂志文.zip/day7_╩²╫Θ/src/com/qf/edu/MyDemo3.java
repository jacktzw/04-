package com.qf.edu;

public class MyDemo3 {

	public static void main(String[] args) {
		int OldArr[] = { 1, 2, 3, 4, 5 }; // ԭ����һ
		int OldArr1[] = { 6, 7, 8 }; // ԭ�����
		int newArr[] = new int[OldArr.length + OldArr1.length];// ������
		for (int i = 0; i < newArr.length; i++) {
			if (i < OldArr.length) {
				newArr[i] = OldArr[i];
			} else {
				newArr[i] = OldArr[i - OldArr.length];
			}
		}

		for (int i = 0; i < OldArr.length; i++) {
			newArr[i] = OldArr[i];
		}
		for (int i = 0; i < OldArr1.length; i++) {
			newArr[i + OldArr.length] = OldArr1[i];
		}

		for (int i = 0; i < newArr.length; i++) {
			System.out.print(newArr[i] + " ");
		}
	}

}
