package com.qfedu.demo6;

import java.util.Scanner;

public class Demo5 {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("����������ĳ��ȣ�");
		int n= sc.nextInt();
		String[] str = new String[n];
		for(int i = 0;i < str.length;i++){
			System.out.println("������str["+i+"]��ֵ");
			String name =sc.next();
			str[i] = name;
		}
		for(int i = 0;i < str.length;i++){
			if(i % 2 ==0){
				System.out.println("str["+i+"]="+str[i]);
			}
		}
	}

}
