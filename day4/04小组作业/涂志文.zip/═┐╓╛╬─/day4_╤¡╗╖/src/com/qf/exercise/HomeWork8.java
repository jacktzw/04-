package com.qf.exercise;

import java.util.Random;
import java.util.Scanner;

/**
 * 
 * @author tzw  
 * @date 2020��7��23��
 * <p>Description: </p>
 */
public class HomeWork8 {
      
	   public static void main(String[] args) {
		  
			Random random = new Random();
			int number = random.nextInt(100)+1;
//	         System.out.println("�����Ϊ:"+number);
			boolean b = true;
			int n=1;
			while (b) {
				System.out.println("�������1-100֮��");
				Scanner sc = new Scanner(System.in);
				int s = sc.nextInt();
				if (s == number) {
					System.out.println("������"+n+"�β¶�");
					b=false;
					sc.close();
				} else {
					System.out.println(s>number?"��´���":"��С��");
				}
				n++;
			}
			
	}
}
