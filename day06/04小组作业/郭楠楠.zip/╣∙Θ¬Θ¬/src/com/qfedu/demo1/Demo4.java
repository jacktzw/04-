package com.qfedu.demo1;

import java.util.Scanner;

public class Demo4 {
	public static void main(String[] args){
		System.out.println("����������:");
		Scanner sc = new Scanner(System.in);
		int age = sc.nextInt();
		String name = age > 35 ? "����":"С��";
		System.out.println(name);
		sc.close();
	}

}
