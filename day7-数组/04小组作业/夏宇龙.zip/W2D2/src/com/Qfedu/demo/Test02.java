package com.Qfedu.demo;

import java.util.Random;

public class Test02 {
	public static void main(String[] args) {
		int [] a=new int [5];
		int s=0;
		for(int i=0;i<a.length;i++) {
			Random rand=new Random();
			int number=rand.nextInt(100);
			a[i]=number;
			System.out.print(a[i]+"\t");
			s+=a[i];
		}
		System.out.println("\n����Ԫ�صĺ�Ϊ��"+s);
	}
}
