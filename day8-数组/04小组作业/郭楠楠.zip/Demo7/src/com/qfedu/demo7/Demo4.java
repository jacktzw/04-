package com.qfedu.demo7;

public class Demo4 {
	public static void main(String[] args){
		int[] arr = new int[]{8,2,9,5,3};
			for(int i = 0;i < arr.length / 2;i++){
				arr[i] = arr[i]^arr[arr.length - i - 1];
				arr[arr.length - i - 1] = arr[i]^arr[arr.length - i - 1];
				arr[i] = arr[i]^arr[arr.length - i - 1];
			}
			for(int i = 0;i < arr.length;i++){
				System.out.print(arr[i] + " ");
			}
	}
}
		