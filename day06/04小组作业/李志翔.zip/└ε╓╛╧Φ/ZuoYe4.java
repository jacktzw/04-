package com.qianfeng.day2;

import java.util.Scanner;

public class ZuoYe4 {

	public static void main(String[] args) {
		// 
		Scanner in = new Scanner(System.in);
		System.out.println("���������䣺");
		int age = in.nextInt();
		String name = "����";
		String name1 = "С��";
		String n = age > 35 ? name : name1;
		System.out.println(n);
	}

}
