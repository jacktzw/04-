package com.qf.lzx.homhwork;

import java.util.Arrays;
import java.util.Random;

public class HomeWork4 {

	public static void main(String[] args) {
		// �󳤶�Ϊ5�����������е����ֵ
		int[] arr = new int[5];
		Random rand = new Random();
		
		int num = 0;
		for (int i = 0; i < arr.length; i++) {
			arr[i] = rand.nextInt(100);
			if (arr[i] > num) {
				num = arr[i];
			}
		}
		System.out.println(num);
		System.out.println(Arrays.toString(arr));

	}

}
