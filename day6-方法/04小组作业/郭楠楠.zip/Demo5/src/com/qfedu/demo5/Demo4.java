package com.qfedu.demo5;

public class Demo4 {
	public static void main(String[] args){
		show();
	}
	public static void show(){
		for(int i = 0;i <= 4;i++){
			for(int j = 0;j <= i;j++){
				System.out.print("*");
			}
			System.out.println();
		}
	}

}
