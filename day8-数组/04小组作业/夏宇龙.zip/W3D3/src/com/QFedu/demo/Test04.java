package com.QFedu.demo;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Test04 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("���ٸ�����");
		int n=input.nextInt();
		input.close();
		int[] arr = new int[n];
		Random random = new Random();
		for (int i = 0; i < arr.length; i++) {
			arr[i] = random.nextInt(100);
		}
		System.out.println("ԭ     ����"+Arrays.toString(arr));
		for(int i=0;i<arr.length/2;i++) {
			arr[i]=arr[i]^arr[arr.length-i-1];
			arr[arr.length-i-1]=arr[i]^arr[arr.length-i-1];
			arr[i]=arr[i]^arr[arr.length-i-1];
		}
		System.out.println("�����"+Arrays.toString(arr));
	}
}
