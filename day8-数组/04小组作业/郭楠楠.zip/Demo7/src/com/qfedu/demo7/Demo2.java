package com.qfedu.demo7;

import java.util.Random;

public class Demo2 {
	public static void main(String[] args){
		System.out.println("����ǰ��");
		Random random = new Random();
		int[] arr = new int[10];
		for(int i = 0;i < arr.length;i++){
			arr[i] = random.nextInt(100);
			System.out.print(arr[i]+" ");
		}
		for(int i = 0;i < arr.length;i++){
			int min = arr[i];
			int index = -1;
			for(int j = i+1;j < arr.length;j++){
				if(min > arr[j]){
					min = arr[j];
					index = j;
				}
			}
			if(index != -1){
				arr[i] = arr[i]^arr[index];
				arr[index] = arr[i]^arr[index];
				arr[i] = arr[i]^arr[index];
			}
		}
		System.out.println();
		System.out.println("�����");
		for(int i = 0;i < arr.length;i++){
			System.out.print(arr[i]+" ");
		}
	}

}
