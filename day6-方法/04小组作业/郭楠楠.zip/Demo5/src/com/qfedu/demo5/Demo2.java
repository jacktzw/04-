package com.qfedu.demo5;

public class Demo2 {
	public static void main(String[] args){
		show();
	}
	public static void show(){
		int count = 0;
		for(int i = 10000;i <= 99999;i++){
			int g = i % 10;
			int s = i / 10 % 10;
			int q = i / 1000 % 10 ;
			int w = i / 10000;
			if(g == w && s == q){
				System.out.print(i+" ");
				count++;
				if(count % 10 == 0){
					System.out.println();
				}
			}
		}
		
	}

}
