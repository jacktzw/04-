package com.qf.edu;

import java.util.Arrays;

public class MyDemo5 {

	public static void main(String[] args) {
		
		int [] arr1= {10,20,30,40};
		int [] arr2= {50,60};
		int [] arr3= {70,80};
		//int [] arr4=new int[arr1.length+arr2.length+arr3.length];
		//ʹ��System.arraycopy���п���
		int [] arr4=Arrays.copyOf(arr1, arr1.length+arr2.length+arr3.length);
		//System.arraycopy(arr1, 0, arr4, 0, arr1.length);
		System.arraycopy(arr2, 0, arr4, arr1.length, arr2.length);
		System.arraycopy(arr3, 0, arr4, arr1.length+arr2.length, arr3.length);
		
		System.out.println(Arrays.toString(arr4));
		
		/*
		 * for (int i = 0; i < arr4.length; i++) { System.out.print(arr4[i]+","); }
		 */
		
	}

}
