package com.qfedu.demo2;

import java.util.Scanner;

public class Demo3 {
	public static void main(String[] args){
		System.out.println("�������ֻ��۸�");
		Scanner sc = new Scanner(System.in);
		double price = sc.nextDouble();
		if(price > 5000){
			System.out.println("ȥ��iPhone");
		}
		else{
			System.out.println("Android�ֻ�Ҳ��");
		}
		sc.close();
	}

}
