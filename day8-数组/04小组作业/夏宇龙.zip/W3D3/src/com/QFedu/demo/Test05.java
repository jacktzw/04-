package com.QFedu.demo;

import java.util.Random;

public class Test05 {
	public static void main(String[] args) {
		int[][] arr = new int[5][5];
		int s=0,count=0;
		Random random = new Random();
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				arr[i][j] = random.nextInt(100);
				s+=arr[i][j];
				count++;
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
		double  avg=(double) s/count;
		System.out.println("ƽ������"+avg);
		s=0;
		count=0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				if(arr[i][j]>avg) {
					s+=arr[i][j];
				count++;
				}			
			}
		}
		System.out.println("���д���ƽ����������֮��Ϊ��"+s+",����"+count+"��.");
	}
}
