package com.qf.day3.zuoye;



public class ZuoYe8 {

	public static void main(String[] args) {
		int num = 10000;

		
		while(num<=99999) {
			int g = num % 10; //��λ��
			int s = num / 10 % 10; //ʮλ��
			int b = num / 100 % 10; //��λ��
			int q = num / 1000 % 10; //ǧλ��
			int w = num / 10000;//��λ��
			if(g==w && s==q) {
				
				System.out.println(num);
			}
			num++;
		}

	}

}
