package com.qf.edu;

import java.util.Random;

public class MyDemo {

	public static void main(String[] args) {
		int a[]=new int[5];
		Random random=new Random();
		int sum=0;
		int sum1=0;
		for (int i = 0; i < a.length; i++) {
			 a[i]=random.nextInt(100);
			 System.out.println(a[i]);
			 sum+=a[i];
		}
		
		
		for (int i : a) {
			sum1+=i;
		}
		System.out.println("ƽ����Ϊ:"+sum1/a.length*1.0);
		
		
		/*
		 * for (int i = 0; i < a.length; i++) { sum+=a[i]; }
		 */
		System.out.println("ƽ����Ϊ:"+sum/a.length*1.0);
		
		/*
		 * a[0]="����֤ȯ"; a[1]="��̩����֤ȯ"; a[2]="����֤ȯ";
		 */
		/*for (int s : a) {
			System.out.println(s);
		}*/
		/*
		 * for (int i = 0; i < a.length; i++) { System.out.println("��"+(i+1)+"Ϊ:"+a[i]);
		 * }
		 */
	}

}
