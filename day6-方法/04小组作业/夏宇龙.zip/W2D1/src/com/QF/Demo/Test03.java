package com.QF.Demo;

import java.util.Scanner;

public class Test03 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Please input your number:");
		int n=input.nextInt();
		input.close();
		sanJiao(n);
	}

	private static void sanJiao(int n) {
		for(int i=0;i<n;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print("* ");
			}
			System.out.println();
		}
	}
}
