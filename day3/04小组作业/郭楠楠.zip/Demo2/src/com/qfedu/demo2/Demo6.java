package com.qfedu.demo2;

import java.util.Scanner;

public class Demo6 {
	public static void main(String[] args){
		System.out.println("�������һ�����֣�");
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		System.out.println("������ڶ������֣�");
		int b = sc.nextInt();
		int beishu = 0;
		int yueshu = 0;
		yueshu = Demo6.gonyue(a,b);
		beishu = Demo6.gonbei(a, b,yueshu);
		System.out.println("���Լ��Ϊ"+yueshu);
		System.out.println("��С������Ϊ"+beishu);
		sc.close();
		
	}
	public static int gonyue(int a,int b){
		if(a > b){
			int temp = b;
			b = a;
			a = temp; 
		}
		while(a != 0){
			int t = b%a;
			b = a;
			a = t;
		}
		return b;
		}
	public static int gonbei(int a,int b,int yueshu){
		int x = a*b/yueshu;
		return x;
	}
	

}
