package com.qianfeng.day2;

import java.security.KeyStore.TrustedCertificateEntry;
import java.util.Scanner;

public class ZuoYe3 {

	public static void main(String[] args) {
		// 
		Scanner in = new Scanner(System.in);
		System.out.println("��������ݣ�");
		int y = in.nextInt();
//		if(y % 400 == 0 || y % 4 == 0 && y % 100 != 0 ) {
//			System.out.println(true);
//		}else{
//			System.out.println(false);
//		}
		boolean b = y % 400 == 0 || y % 4 == 0 && y % 100 != 0 ? true : false;
		System.out.println(b);
	}

}
