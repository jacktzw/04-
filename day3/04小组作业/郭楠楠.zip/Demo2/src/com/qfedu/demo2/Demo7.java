package com.qfedu.demo2;

public class Demo7 {
	public static void main(String[] args){
		int i = 0;
		for(int num=10000;num <100000;num++){
			int g;
			int s;
			int b;
			int q;
			int w;
			g = num % 10;
			s = num / 10 % 10;
			b = num / 100 % 10;
			q = num / 1000 % 10;
			w = num / 10000;
			if(g == w && s == q){
				System.out.print(num+"  ");
				i++;
				if(i % 10 == 0){
				System.out.print("\n");
			}
			}
			
		}
	}

}
