package com.qfedu.demo5;

import java.util.Scanner;

public class Demo7 {
	public static void main(String[] args){
		System.out.println("��������������");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int m = sc.nextInt();
		if(n > m){
			m = n^m;
			n = n^m;
			m = n^m;
		}
		show(n,m);
	}
	public static void show(int n,int m){
		for(int i = n;i <= m;i++){
			boolean f = diaoYon(i);
			while(f){
				System.out.print(i+"  ");
				break;
			}
		}
	}
	public static boolean diaoYon(int i){
		boolean m = true;
		for(int j = 2;j < i;j++){
			if(i % j == 0){
				m = false;
			}
		}
		return m;
		
	}

}
