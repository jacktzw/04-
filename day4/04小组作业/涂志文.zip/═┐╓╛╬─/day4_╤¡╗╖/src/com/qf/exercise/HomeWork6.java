package com.qf.exercise;
/**
 * 
 * @author tzw  
 * @date 2020��7��23��
 * <p>Description: </p>
 */
public class HomeWork6 {
      
	   public static void main(String[] args) {
//		   6������ 1+2-3+4-5+6-7....+100�Ľ��
		   int sum=0;
		   for (int i = 1; i <= 100; i++) {
			    if(i%2==0||i==1) {
			    	sum+=i;
			    }else {
			    	sum-=i;
			    }
		}
		   System.out.println("���Ϊ:"+sum);
	}
}
