package cn.qf.lzx.homework;

public class HomeWork5 {

	public static void main(String[] args) {
		// ������е�3λˮ�ɻ���
		sum();
	}
	public static void sum() {
		for (int i = 100; i < 1000; i++) {
			boolean b = isShuiXianHuaSu(i);
			if (b) {
				System.out.println(i+"��ˮ�ɻ���");
			}
		}
	}
	public static boolean isShuiXianHuaSu(int i) {
		int sum = 0;
		if(i == (i%10)*(i%10)*(i%10) + (i%100/10)*(i%100/10)*(i%100/10) + (i/100)*(i/100)*(i/100)) {
			sum = sum + i;
			return true;
		}
		return false;
	}
	

}
