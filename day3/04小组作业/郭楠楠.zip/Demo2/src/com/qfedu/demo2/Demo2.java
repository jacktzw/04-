package com.qfedu.demo2;

import java.util.Scanner;

public class Demo2 {
	public static void main(String[] args){
		System.out.println("��������ݣ�");
		Scanner sc = new Scanner(System.in);
		int year = sc.nextInt();
		System.out.println("�������·ݣ�");
		int month = sc.nextInt();
		int sum = 0;
		switch(month){
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				sum = 31;
				break;
			case 2:
			if(year % 400 == 0 || year % 4 ==0 && year % 100 != 0){
				sum = 29;
			}
			else{
			sum = 28;
			}
			break;
			case 4:
			case 6:
			case 9:
			case 11:
				sum = 30;
				break;
		}
		System.out.println(year+"��"+month+"����"+sum+"��");
		sc.close();
	}

}
