package com.qf.day4.zuoye;

public class HomeWork1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
