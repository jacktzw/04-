package com.qf.day4.zuoye;

public class Homework6 {

	public static void main(String[] args) {
		// ���� 1+2-3+4-5+6-7....+100�Ľ��
		int sum = 1;
		for (int i = 2; i <= 100; i++) {
			if (i % 2 != 0) {
				sum += i*(-1);
//				System.out.println(sum);
			}else {
				sum += i;	
//				System.out.println(sum);
			}
			
		}
		System.out.println(sum);
	}

}
