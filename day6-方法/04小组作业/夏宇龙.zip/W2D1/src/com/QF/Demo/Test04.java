package com.QF.Demo;

import java.util.Scanner;

public class Test04 {
		public static void main(String[] args) {
			Scanner input = new Scanner(System.in);
			System.out.print("How much days?:");
			int n=input.nextInt();
			input.close();			
			System.out.println("�����"+fruit(n)+"������");
	}

		private static int fruit(int n) {
			int s=1;
			for(int i=0;i<n;i++) {
				s*=2;
			}
			return s;
		}
}
