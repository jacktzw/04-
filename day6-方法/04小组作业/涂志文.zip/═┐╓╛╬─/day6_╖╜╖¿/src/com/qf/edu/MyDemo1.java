package com.qf.edu;

public class MyDemo1 {
	public static void main(String[] args) {
		  double avg=getAvg(1, 2);// 2 4 6 8 10 
		  System.out.println(min(3,5)); //
		  System.out.println(avg);
	}
	public static double getAvg(int n,int m) {
		double sum = 0;
		int temp=0;
		for (int i = n; i <= m; i++) {
			if(i%2==0) {
				sum += i;
				temp++;
			}
			
		}
		return sum/temp;
	}
	public static int  min(int a ,int b) {
		if(a>b) {
			System.out.println("-----------");
			return b;
		}
		return a;
		
	}

}
