package com.qfedu.demo6;

import java.util.Random;

public class Demo3 {
	public static void main(String[] args){
		int[] arr = new int[5];
		int sum = 0;
		for(int i = 0;i < arr.length;i++){
			Random random = new Random();
			arr[i] = random.nextInt(100);
			sum += arr[i];
		}
		for(int i = 0;i < arr.length;i++){
			System.out.print(arr[i]);
			if(i != arr.length - 1){
				System.out.print(",");
			}
		}
		System.out.println();
		System.out.println("sum="+sum);
	}

}
