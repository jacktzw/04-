package com.qfedu.demo3;

import java.util.Scanner;

public class Demo1 {
	public static void main(String[] args){
		System.out.println("������һ�����֣�");
		Scanner sc = new Scanner(System.in);
		int number = sc.nextInt();
		int num = number;
		String str = number+"=";
		boolean b = true;
		int fina = number;
		for(int i = 2;i < num;i++){
			if(num % i == 0){
				str += (i+"��");
				num = num / i;
				b = false;
				fina = fina / i;
				i = 1;
			}
		}
		
		if(b){
			str += +1+"��"+number;
		}else{
			str += fina; 
		}
		System.out.println(str);
		sc.close();
	}

}
