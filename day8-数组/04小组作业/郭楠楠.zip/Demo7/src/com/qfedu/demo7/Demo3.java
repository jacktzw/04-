package com.qfedu.demo7;

import java.util.Arrays;
import java.util.Random;

public class Demo3 {
	public static void main(String[] args){
		System.out.println("����ǰ��");
		Random random = new Random();
		int[] arr = new int[10];
		for(int i = 0;i < arr.length;i++){
			arr[i] = random.nextInt(100);
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		System.out.println("�����");
		Arrays.sort(arr);
		for(int i = 0;i < arr.length;i++){
			System.out.print(arr[i]+" ");
		}
		
	}

}
