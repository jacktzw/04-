package com.QF.Demo;

public class Test01 {
	public static void main(String[] args) {
		int count=0;
		for(int i=10000;i<100000;i++) {
			if(huiWen(i)) {
				System.out.print(i+"\t");
				count++;
				if(count%10==0) {
					System.out.println();
				}
			}
		}
	}
	
	public static boolean huiWen(int n) {
		int a=n%10;
		int b=n/10%10;
		int d=n%1000%10;
		int e=n/10000;
		if(a==e&&b==d) {
			return true;
			}
		return false;

	}
}
