package com.qfedu.demo6;

import java.util.Scanner;

public class Demo1 {
	public static void main(String[] args){
		int index = -1;
		int[] newarr = new int[7];
		int[] arr = {1,2,3,4,5,6,7,8};
		System.out.println("ԭ�������£�");
		for(int i = 0;i < arr.length;i++){
			System.out.print(arr[i]);
			if(i != arr.length - 1){
				System.out.print(",");
			}
		}
		System.out.println();
		System.out.println("������Ҫɾ���ı�����");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		for(int i = 0;i < arr.length;i++){
			if(n == arr[i]){
				index = i;
			}
		}
		 System.arraycopy(arr, 0, newarr, 0, index);
		 System.arraycopy(arr, index + 1, newarr, index, newarr.length - index);
		 System.out.println("���������£�");
		 for(int i = 0;i < newarr.length;i++){
			 System.out.print(newarr[i]);
				if(i != newarr.length - 1){
					System.out.print(",");
				}
			 
		 }
	}

}
