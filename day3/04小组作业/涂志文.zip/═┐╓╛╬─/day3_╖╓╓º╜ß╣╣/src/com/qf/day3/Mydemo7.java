package com.qf.day3;

/**
 * 
 * @author tzw
 * @date 2020��7��22��
 *       <p>
 *       Description:
 *       </p>
 */
public class Mydemo7 {
	public static void main(String[] args) {

		// ��1-100�ĺ�
		/*
		 * int n = 1; int sum = 0; while (n <= 100) { sum += n; n++; }
		 * System.out.println(sum);
		 */
		// 1-100֮��ż���ĺ�
		/*
		 * int n = 0; int sum = 0;
		 */
		/*while (n <= 100) {

			if (n % 2 == 0) {
				sum += n;
			}
			n++;*/

			/*
			 * sum+=n; n+=2;
			 */
			//�������3λ��ˮ�ɻ��� 100-999
			int n=100; //123
			System.out.print("ˮ�ɻ���Ϊ:");
			while(n<=999) {
				int unit=n/1%10;
				int tens=n/10%10;
				int hunderd=n/100%10;
				if(unit*unit*unit+tens*tens*tens+hunderd*hunderd*hunderd==n) {
					System.out.print(" "+n);
				}
				n++;
			}
		//}
		//System.out.println("1-100֮��ż��֮��Ϊ:" + sum);

	}
}
