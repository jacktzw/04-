package com.qf.day4;

import java.util.Random;
import java.util.Scanner;

public class MyDemo1 {
	public static void main(String[] args) {
		//52 110100
		boolean b=true;
		System.out.println("������");
		Random random=new Random(); 
		int s=random.nextInt(11)+10;
	    int num;
		 do {
			 Scanner sc =new Scanner(System.in);
			  num=sc.nextInt();
			 System.out.println("�����Ϊ:"+s);
			 System.out.println(s==num?"�¶���":"������");
			 if(s==num) b=false;
			
		 }while(b);
	}

}
