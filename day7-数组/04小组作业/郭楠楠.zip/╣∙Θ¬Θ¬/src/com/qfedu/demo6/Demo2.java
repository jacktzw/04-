package com.qfedu.demo6;

import java.util.Scanner;

public class Demo2 {
	public static void main(String[] args){
			Scanner sc = new Scanner(System.in);
			System.out.println("����������ĳ��ȣ�");
			int n = sc.nextInt();
			int[] a = new int[n];
			for(int i = 0;i < a.length;i++){
				System.out.println("������a["+i+"]��ֵ");
				int m =sc.nextInt();
				a[i] = m;
			}
			for(int i = 0;i < 5;i++){
				System.out.print("a["+i+"]="+a[i]);
				if(i != 4){
					System.out.print(",");
				}
			}
			sc.close();
		}
		
	}

