package com.QF.Demo;

public class Test05 {
	public static void main(String[] args) {
		for(int i=100;i<1000;i++) {
			if(shuixina(i)) {
				System.out.println(i);
			}
		}
	}

	private static boolean shuixina(int i) {
		int a=i%10;
		int b=i/10%10;
		int c=i/100;
		if(a*a*a+b*b*b+c*c*c==i) {
			return true;
		}
		return false;
	}
	
}
