package com.Qfedu.demo;

import java.util.Scanner;

public class Test05 {
	public static void main(String[] args) {
		int[] arr=new int[10];
		double s=0;
		Scanner input=new Scanner(System.in);
		for(int i=0;i<arr.length;i++) {
			System.out.print("��"+(i+1)+"��ѧ���ɼ���");
			arr[i]=input.nextInt();
			s+=arr[i];
		}
		input.close();
		int max=arr[0];
		for(int i=1;i<arr.length;i++) {
			if(arr[i]>max) {
				max=arr[i];
			}
		}
		System.out.println("ƽ���֣�"+s/arr.length+",��߷֣�"+max);
	}
}
