package com.QF.Demo;

import java.util.Scanner;

public class Test06 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Please input your first number:");
		int a = input.nextInt();
		System.out.print("Please input your second number:");
		int b = input.nextInt();
		input.close();
		int num = zhiShu(a, b);
		System.out.println("����" + num + "������");
	}

	private static int zhiShu(int a, int b) {
		int count = 0;
		if (b < a) {
			a = a ^ b;
			b = a ^ b;
			a = a ^ b;
		}
		for (; a <= b; a++) {
			int i = 2;
			for (; i <= a; i++) {
				if (a % i == 0)
					break;
			}
			if (i == a) {
				count++;
			}
		}
		return count;
	}
}
