package com.Qfedu.demo;

import java.util.Scanner;

public class Test06 {
	public static void main(String[] args) {
		String[] arr= {"Tom","Jerry","Allen","Oliver","Skye"};
		Scanner input=new Scanner(System.in);
		System.out.print("Ҫ����������");
		String name=input.next();
		input.close();
		boolean flag=false;
		for(int i=0;i<arr.length;i++) {
			if(name.equals(arr[i])) {
				System.out.println("��"+(i+1)+"λ");
				flag=true;
			}
		}
		if(!flag) {
			System.out.println("û�и����ֻ�Ӣ�Ĵ�Сд����");
		}
	}
}
