package com.qf.day4.zuoye;

public class HomeWork7 {
	public static void main(String[] args) {
		//������
		for (int j = 2; j < 1000; j++) {
			
		
			int num = j;
			int sum = 0;
			for (int i = 1; i < num; i++) {
				if (num % i == 0) {
					sum += i;
				}
			}
			if (sum == num) {
				System.out.println(num+"������");
			}
		}
	}
}
