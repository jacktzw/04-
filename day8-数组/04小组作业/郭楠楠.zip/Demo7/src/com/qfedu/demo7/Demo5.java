package com.qfedu.demo7;

import java.util.Random;

public class Demo5 {
	public static void main(String[] args){
		Random random = new Random();
		int[][] arr = new int[5][5];
		double sum = 0.0;
		int num = 0;
		int count = 0;
		for(int i = 0;i < arr.length;i++){
			for(int j = 0;j < arr[i].length;j++){
				arr[i][j] = random.nextInt(100);
				sum += arr[i][j];
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
		for(int i = 0;i < arr.length;i++){
			for(int j = 0;j < arr[i].length;j++){
				if(arr[i][j] > sum / 25){
					num += arr[i][j];
					count++;
				}
			}
			
		}
		System.out.println("�ܺ�Ϊ��"+sum);
		System.out.println("ƽ����Ϊ��"+sum / 25);
		System.out.println("����ƽ����������֮��Ϊ��"+num);
		System.out.println("����Ϊ��"+count);
	}

}
