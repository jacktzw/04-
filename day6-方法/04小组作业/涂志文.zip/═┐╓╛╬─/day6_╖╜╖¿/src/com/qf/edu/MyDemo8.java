package com.qf.edu;
/**
 * 
 * @author tzw  
 * @date 2020��7��27��
 * <p>Description: </p>
 */
public class MyDemo8 {
	
	public static void main(String[] args) {
		
	}
    // a b c
	// 1 1 2
	public  static int f(int n) {
		int a=1;
		int b=1;
		int c=0;
		if(n<2) {
			 return 1;
		 }
		for (int i = 3; i <= n; i++) {
			c=a+b;
			a=b;
			b=c;
		}
		return c;
		
	}

}
