package com.qf.day4;

public class MyDemo8 {
	 public static void main(String[] args) {
  		   
		/*
		 * for (int j = 0; j < 3; j++) {
		 * 
		 * for (int i = 0; i < 5; i++) { System.out.print("*"); } System.out.println();
		 * }
		 */
		/*
		 * for (int i = 0; i <3; i++) { for (int j = 0; j <=i; j++) {
		 * System.out.print("*"); } System.out.println(); }
		 */
		/*
		 * for (int i = 1; i <= 3; i++) { for (int j = 0; j <i*2-1; j++) {
		 * System.out.print("*"); } System.out.println(); }
		 */
		 //��1-10�׳˵ĺ� 1 2 6 24
		
		 int temp=0;
		 for (int i = 1; i <=10; i++) {
		 int sum=1;
			for (int j = 1; j <=i; j++) {
				sum*=j;
			}
			System.out.println(i+"�׳�Ϊ:"+sum);
			temp+=sum;
			System.out.println("��ǰ�׳�֮��Ϊ:"+temp);
		}
		 System.out.println("���׳��ܺ�Ϊ:"+temp);
		 
	}

}
