package com.qfedu.demo5;

import java.util.Scanner;

public class Demo5 {
	public static void main(String[] args){
		System.out.println("������һ��n:");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		System.out.println(show(n));
		sc.close();
	}
	public static int show(int m){
		int sum = 1;
		for(int i = 1;i <= m;i++){
			sum *= 2;
		}
		return sum;
	}

}
