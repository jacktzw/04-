package com.qfedu.demo1;

import java.util.Scanner;

public class Demo3 {
	public static void main(String[] args){
		System.out.println("���������:");
		Scanner sc = new Scanner(System.in);
		int number = sc.nextInt();
		boolean result = (number % 400 == 0 || (number % 4 ==0 && number % 100 != 0)) ? true : false;
		System.out.println("�Ƿ�Ϊ����:"+"\n"+result);
		sc.close();
	}

}
