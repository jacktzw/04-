package com.qf.edu;

public class MyDemo6 {

	public static void main(String[] args) {
		int sum = jiecheng(5);
		System.out.println(sum);

	}

	public static int jiecheng(int n) {
		if (n == 1) {
			return 1;
		}
		return n * jiecheng(n - 1);

	}
}
