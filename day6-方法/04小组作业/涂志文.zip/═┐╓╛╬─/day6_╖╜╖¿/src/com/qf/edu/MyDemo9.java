package com.qf.edu;
/**
 * 
 * @author tzw  
 * @date 2020��7��27��
 * <p>Description: </p>
 */
public class MyDemo9 {
	      //         a b c
          //쳲���������  1 1 2 3 5 8
	      //           a b c
	public static void main(String[] args) {
		print(10000);
	}
	public static void print(int n) {
		for (int i = 1; i <=n; i++) {
			int sum=xunhuan(i);
			System.out.println("��"+i+"��Ϊ:"+sum);
		}
	}
	public static int f(int n) {
		if(n==1||n==2) {
			return 1;
		}
		return f(n-1)+f(n-2);
	}
	public static int xunhuan(int n) {
		if(n==1||n==2) {
			return 1;
		}
		int a=1;
		int b=1;
		int c=0;
		  //         a b c
        //쳲���������  1 1 2 3 5 8
	    
		for (int i = 3; i <=n; i++) {
			c=a+b;
			a=b;
			b=c;
			
		}
		return c;
	}
}
