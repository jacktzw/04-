package com.qfedu.demo1;

public class Demo1 {
	public static void main(String[] args){
		int a = 3;
		int b = 2;
		int res1 = (a++)*(--b)+(--a)/(b++);
		System.out.println(res1);
	}

}
