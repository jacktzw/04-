package com.qf.edu;

import java.util.Arrays;

public class MyDemo7 {

	public static void main(String[] args) {
		int [] arr= {1,2,3}; //ԭ����
		int num=4;
		arr=swap(arr, num);
		System.out.println(Arrays.toString(arr));
		
	}
	public static int [] swap(int [] arr,int num) {
		int [] newArr=new int[arr.length+1]; //����������
		System.arraycopy(arr, 0, newArr, 0, arr.length); //��ֵ
		newArr[arr.length]=4;
		return newArr;
	}

}
