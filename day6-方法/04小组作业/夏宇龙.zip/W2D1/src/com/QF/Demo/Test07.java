package com.QF.Demo;
import java.util.Scanner;

public class Test07 {
	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		System.out.print("Please input your first number:");
		int m=input.nextInt();
		System.out.print("Please input your second number:");
		int n=input.nextInt();
		input.close();
		System.out.println(chengJi(m,n));
	}

	private static int chengJi(int m,int n) {
		int s=1;
		if(m>n) {
			m=m^n;
			n=m^n;
			m=m^n;
		}
		for(;m<=n;m++ ) {
			s*=m;
		}
		return s;
	}
	
}
