package com.qfedu.demo5;

import java.util.Scanner;

public class Demo3 {
	public static void main(String[] args){
		System.out.println("������һ������n:");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		show(n);
	}
	public static void show(int m){
		for(int i = 0;i <= m;i++){
			for(int j = 0;j <= m-i;j++){
				System.out.print(" ");
			}
			for(int j = 1;j <= 2*i - 1;j++){
				System.out.print("*");
			}
			System.out.println();
		}
	}

}
