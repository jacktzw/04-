package com.QF.Demo;

public class Test02 {
	public static void main(String[] args) {
		sanJiao();
	}
	public static void sanJiao() {
		for(int i=0;i<5;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print("* ");
			}
			System.out.println();
		}
	}
}
