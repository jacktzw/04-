package com.qfedu.demo3;

public class Demo3 {
	public static void main(String[] args){
		double height = 0.00008;
		int i;
		for( i = 1; ;i++){
			height *= 2;
			if(height >= 8848.13){
				break;
			}
		}
		System.out.println(i);
	}

}
