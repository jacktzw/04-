package com.qf.day3.zuoye;

import java.util.Scanner;

public class ZuoYe3 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("���ж���Ǯ��");
		int money = in.nextInt();
		if(money>5000) {
			System.out.println("ȥ��IPHONE");
		}else {
			System.out.println("Android�ֻ�Ҳ��");
		}

	}

}
