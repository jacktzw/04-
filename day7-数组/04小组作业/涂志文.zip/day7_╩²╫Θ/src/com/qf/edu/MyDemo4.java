package com.qf.edu;

public class MyDemo4 {

	public static void main(String[] args) {
		int OldArr[] = { 1, 2, 3, 4, 5 }; // ԭ����һ
		int OldArr1[] = { 6, 7, 8 }; // ԭ�����
		int newArr[] = new int[OldArr.length + OldArr1.length];// ������
		System.arraycopy(OldArr, 0, newArr, 0, OldArr.length);
		System.arraycopy(OldArr1, 0, newArr, OldArr.length, OldArr1.length);
		for (int i = 0; i < newArr.length; i++) {
			System.out.print(newArr[i] + " ");
		}
		
	}

}
