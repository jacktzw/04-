package com.Qfedu.demo;
import java.util.Arrays;

public class Test04 {
	public static void main(String[] args) {
		int [] arr= {23,12,34,37,41};
		int max=arr[0];
		for(int i=1;i<arr.length;i++) {
			if(arr[i]>max) {
				max=arr[i];
			}
		}
		System.out.println(Arrays.toString(arr)+"\n���ֵΪ��"+max);
	}
}
