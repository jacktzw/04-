package com.qf.exercise;

public class HomeWork5 {
	public static void main(String[] args) {
//		5��������е�3λˮ�ɻ��� 123
		printLine(100,1000);
      		
	}
	public static void printLine(int m,int n) {
		for (int i = m; i <= n; i++) {
			if(isShuiXian(i)==true) {
				System.out.println("ˮ�ɻ���:"+i);
			}
		}
	}
	
	public static boolean isShuiXian(int n ) {
		int g=n/1%10;
		int s=n/10%10;
		int b=n/100%10;
		return g*g*g+s*s*s+b*b*b==n;
	}
}
