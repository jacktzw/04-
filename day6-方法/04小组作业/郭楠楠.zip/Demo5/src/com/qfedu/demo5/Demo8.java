package com.qfedu.demo5;

import java.util.Scanner;

public class Demo8 {
	public static void main(String[] args){
			System.out.println("��������������");
			Scanner sc = new Scanner(System.in);
			int n = sc.nextInt();
			int m = sc.nextInt();
			if(n > m){
				n = n^m;
				m = n^m;
				n = n^m;
			}
			System.out.println(show(n,m));
		}
		public static int show(int n,int m){
			int sum = 1;
			for(int i = n;i <= m;i++){
				sum *= i;
			}
			return sum;
		}
}
