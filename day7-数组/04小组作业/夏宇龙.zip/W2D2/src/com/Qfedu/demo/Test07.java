package com.Qfedu.demo;

import java.util.Arrays;
import java.util.Scanner;

public class Test07 {
	public static void main(String[] args) {
		int [] arr= {1,2,3,4,5};
		int [] newarr=new int[arr.length-1];
		System.out.println(Arrays.toString(arr));
		Scanner input=new Scanner(System.in);
		System.out.println("Ҫɾ��������");
		int num=input.nextInt();
		input.close();
		boolean flag=false;
		for(int i=0;i<arr.length;i++) {
			if(num==arr[i]) {
				flag=true;
				System.arraycopy(arr, 0, newarr,0, i);
				System.arraycopy(arr, i+1, newarr,i, arr.length-i-1);
			}
		}
		if(flag) {
			System.out.println(Arrays.toString(newarr));
			}
		else {
			System.out.println("û�д���");
		}
	}
}
