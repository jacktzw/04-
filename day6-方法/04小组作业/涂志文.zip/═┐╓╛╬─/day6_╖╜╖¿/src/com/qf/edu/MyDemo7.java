package com.qf.edu;

/**
 * 
 * @author tzw
 * @date 2020��7��27��
 *       <p>
 *       Description:
 *       </p>
 */
public class MyDemo7 {
    public static void main(String[] args) {
		print(50);
	}

	public static void print(int n) {
		for (int i = 1; i <= n; i++) {
			int num = f(i);
			System.out.println("��" + i + "����Ϊ" + num);
		}

	}

	public static int f(int n) {
		if (n == 1 || n == 2) {
			return 1;
		}
		return f(n - 1) + f(n - 2);

	}

}
