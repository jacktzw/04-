package com.qf.day3;

public class MyDemo {
           public static void main(String[] args) {
			       int age=24;
			       if(age>25) {
			    	   System.out.println("�㲻����������");
			       }else {
			    	   System.out.println(13);
			       }
			       
		}
}
