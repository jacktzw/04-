package com.qf.day4.zuoye;

public class HomeWork4 {

	public static void main(String[] args) {
		// ��Ǯ��ټ�
		for (int i = 0; i < 100; i++) {
			for (int j = 0; j < 100; j++) {
				for (int k = 0; k < 100; k++) {
					if (i+j+k==100&&i*5+j*3+k/3==100&&k%3==0) {
						System.out.println("������"+i+"ֻ");
						System.out.println("ĸ����"+j+"ֻ");
						System.out.println("������"+k+"ֻ");
					}
				}
			}
		}

	}

}
